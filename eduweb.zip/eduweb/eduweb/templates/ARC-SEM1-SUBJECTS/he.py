import os

# Define the number of pages you want to create
num_pages = 5

# Create a directory for the pages
os.makedirs('pages', exist_ok=True)

# Template for the HTML page
template = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page {number}</title>
</head>
<body>

    <!-- Header Section -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="index.html">
            <img src="images/logo.png" alt="Logo">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.html">HOME</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about.html">ABOUT</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="course.html">COURSE</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact.html">CONTACT</a>
                </li>
            </ul>
        </div>
    </nav>

    

    <!-- Course Section -->
    <h1 class="course">CSE Physics - 1</h1>
    <!-- Course Section -->
    <section class="course text-center">
        <div class="container">
            <div class="row">
                <div class="col-md-3 mb-3">
                    <a href="Subjects.html">
                        <div class="course-column">
                            <h3>Question Papers</h3>
                        </div>
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="Subjects.html">
                        <div class="course-column">
                            <h3>Notes</h3>
                        </div>
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="Subjects.html">
                        <div class="course-column">
                            <h3>Important Questions</h3>
                        </div>
                    </a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3 mb-3">
                    <a href="Subjects.html">
                        <div class="course-column">
                            <h3>Extra Study Material</h3>
                        </div>
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="Subjects.html">
                        <div class="course-column">
                            <h3>MCQ's Type Questions</h3>
                        </div>
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="Subjects.html">
                        <div class="course-column">
                            <h3>Short Work</h3>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>
    <!-- Footer Section -->
    <section class="footer text-center">
        <div class="container">
            <h4>About Us</h4>
            <p>
                Hello! I'm Ravinder Singh. On this website, you'll find a variety of notes and resources tailored
                to support students in their academic journey. Whether you're looking for
                detailed notes, helpful study tips, or additional resources,
                I'm here to provide the tools you need to succeed.
                My goal is to create a supportive learning
                environment where knowledge is easily
                accessible and learning is
                a rewarding experience.
            </p>
           
            <p>Made by | <span style="color: #55C2C3;">Ravinder Singh</span></p>
        </div>
    </section>

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
"""

try:
    for i in range(1, num_pages + 1):
        # Create the filename
        filename = f'pages/page_{i}.html'
        
        # Create and write to the file
        with open(filename, 'w') as file:
            file.write(template.format(number=i))

    print("Pages created successfully!")

except Exception as e:
    print(f"An error occurred: {e}")