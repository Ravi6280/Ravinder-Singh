from django.contrib import admin
from .models import Message, PhysicsQ1, MathsQ1, ChemistryQ1, CFITQ1, EDQ1, ECSQ1  
from .models import CPCQ1, SEQ1,OSQ1,DEQ1,MMAQ1,IWTQ1
from .models import BEQ1, Maths2Q1, EVSQ1, AP2Q1, DTPQ1, ECS2Q1
from .models import CAQ1, CNSQ1, DBMSQ1, DSQ1, GSEDQ1, OOPSQ1
from .models import BOMQ1, CPIQ1, IOTQ1, MicroProcessorQ1, MTQ1, PHPQ1
from .models import ADLQ1, ADWFQ1, CCQ1, CPPQ1, DAAQ1, PHPQ2
# Register your models here.

class MessageAdmin(admin.ModelAdmin):
    list_display = ['name','email','message','date']
    list_filter = ['date']
admin.site.register(Message, MessageAdmin)

admin.site.register(PhysicsQ1)
admin.site.register(MathsQ1)
admin.site.register(ChemistryQ1)
admin.site.register(CFITQ1)
admin.site.register(EDQ1)
admin.site.register(ECSQ1)

admin.site.register(BEQ1)
admin.site.register(Maths2Q1)
admin.site.register(EVSQ1)
admin.site.register(AP2Q1)
admin.site.register(DTPQ1)
admin.site.register(ECS2Q1)

admin.site.register(CPCQ1)
admin.site.register(DEQ1)
admin.site.register(SEQ1)
admin.site.register(OSQ1)
admin.site.register(MMAQ1)
admin.site.register(IWTQ1)

admin.site.register(CAQ1)
admin.site.register(CNSQ1)
admin.site.register(DBMSQ1)
admin.site.register(DSQ1)
admin.site.register(GSEDQ1)
admin.site.register(OOPSQ1)

admin.site.register(BOMQ1)
admin.site.register(CPIQ1)
admin.site.register(IOTQ1)
admin.site.register(MicroProcessorQ1)
admin.site.register(MTQ1)
admin.site.register(PHPQ1)

admin.site.register(ADLQ1)
admin.site.register(ADWFQ1)
admin.site.register(CCQ1)
admin.site.register(CPPQ1)
admin.site.register(DAAQ1)
admin.site.register(PHPQ2)