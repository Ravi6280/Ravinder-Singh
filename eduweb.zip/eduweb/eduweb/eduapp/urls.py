from django.urls import path
from.import views
urlpatterns = [
    path('',views.index, name='index'),
    path('contact_us/', views.contact_us, name="contact_us"),
    path('about/',views.about,name='about'),
    path('course/',views.course,name='course'),
    
    
    
    
    
    path('CSE/',views.CSE,name='CSE'),


    path('CSE1/',views.CSE1,name='CSE1'),

    path('Physics1/',views.Physics1,name='Physics1'),
    path('Maths1/',views.Maths1,name='Maths1'),
    path('CFIT/',views.CFIT,name='CFIT'),
    path('ECS/',views.ECS,name='ECS'),
    path('Chemistry/',views.Chemistry,name='Chemistry'),
    path('ED/',views.ED,name='ED'),

    path('CSE2/',views.CSE2,name='CSE2'),

    path('BE/',views.BE,name='BE'),
    path('Maths2/',views.Maths2,name='Maths2'),
    path('EVS/',views.EVS,name='EVS'),
    path('Phyics2/',views.Phyics2,name='Phyics2'),
    path('DTP/',views.DTP,name='DTP'),
    path('ECS2/',views.ECS2,name='ECS2'),

    path('CSE3/',views.CSE3,name='CSE3'),

    path('CPC/',views.CPC,name='CPC'),
    path('DE/',views.DE,name='DE'),
    path('SE/',views.SE,name='SE'),
    path('OS/',views.OS,name='OS'),
    path('MMA/',views.MMA,name='MMA'),
    path('IWT/',views.IWT,name='IWT'),


    path('CSE4/',views.CSE4,name='CSE4'),

    path('ca/', views.CA, name='ca'),
    path('cns/', views.CNS, name='cns'),
    path('dbms/', views.DBMS, name='dbms'),
    path('ds/', views.DS, name='ds'),
    path('gsed/', views.GSED, name='gsed'),
    path('oops/', views.OOPS, name='oops'),    

    path('CSE5/',views.CSE5,name='CSE5'),

    path('bom/', views.BOM, name='bom'),
    path('cpi/', views.CPI, name='cpi'),
    path('iot/', views.IOT, name='iot'),
    path('microprocessor/', views.MicroProcessor, name='microprocessor'),
    path('mt/', views.MT, name='mt'),
    path('php/', views.PHP, name='php'),

    path('CSE6/',views.CSE6,name='CSE6'),

    path('adl/', views.ADL, name='adl'),
    path('adwf/', views.ADWF, name='adwf'),
    path('cc/', views.CC, name='cc'),
    path('cpp/', views.CPP, name='cpp'),
    path('daa/', views.DAA, name='daa'),
    path('php2/', views.PHP2, name='php2'),

    path('CIVIL/',views.CIVIL,name='CIVIL'),


    path('MECHANICAL/',views.MECHANICAL,name='MECHANICAL'),

    path('ELECTRICAL/',views.ELECTRICAL,name='ELECTRICAL'),

    path('ARC/',views.ARC,name='ARC'),

   
    
]
