from django.shortcuts import render, HttpResponse
from eduapp.models import Message,PhysicsQ1,MathsQ1, ChemistryQ1, CFITQ1, ECSQ1, EDQ1, BEQ1, Maths2Q1, EVSQ1, AP2Q1, DTPQ1, ECS2Q1 
from eduapp.models import CPCQ1,DEQ1,SEQ1,OSQ1,MMAQ1,IWTQ1
from eduapp.models import CAQ1, CNSQ1, DBMSQ1, DSQ1, GSEDQ1, OOPSQ1
from eduapp.models import BOMQ1, CPIQ1, IOTQ1, MicroProcessorQ1, MTQ1, PHPQ1
from eduapp.models import ADLQ1, ADWFQ1, CCQ1, CPPQ1, DAAQ1, PHPQ2
from django.utils import timezone
from .forms import ContactUsForm


def contact_us(request):
    newform = ContactUsForm()
    
    if request.method == 'POST':
        form = ContactUsForm(data=request.POST)
        if form.is_valid():
            message = form.save(commit=False)
            message.date = timezone.now()  # Assuming you have a 'date' field in your model
            message.save()
            return render(request, 'contact-W.html', {'success': True, 'form': newform})
        else:
            return render(request, 'contact-W.html', {'form': form})
    else:
        return render(request, 'contact-W.html', {'form': newform})

# Create your views here.
def index(request):
    return render(request,'index-W.html')

def about(request):
    return render(request,'about-W.html')

def contact(request):
    if request.method=='POST':
        print('we are using request')
    return render(request,'contact-W.html')

def course(request):
    return render(request,'course-W.html')









def CSE(request):
    return render(request,'CSE-SEMESTERS-W.html')

def CSE1(request):
    return render(request,'CSE-SEM1-SUBJECTS/CSE-SEMESTERS1-S.html')

def Physics1(request):
    Physic1Papers = PhysicsQ1.objects.all()
    return render(request,'CSE-SEM1-SUBJECTS/Physics-1.html', {'Physic1Papers': Physic1Papers})

def Maths1(request):
    Maths1Papers = MathsQ1.objects.all()
    return render(request,'CSE-SEM1-SUBJECTS/Maths-1.html', {'Maths1Papers': Maths1Papers})

def CFIT(request):
    CFITPapers = CFITQ1.objects.all()
    return render(request,'CSE-SEM1-SUBJECTS/CFIT.html', {'CFITPapers': CFITPapers})

def ECS(request):
    ECSPapers = ECSQ1.objects.all()
    return render(request,'CSE-SEM1-SUBJECTS/ECS.html',{'ECSPapers': ECSPapers})

def Chemistry(request):
    ChemistryPapers = ChemistryQ1.objects.all()
    return render(request,'CSE-SEM1-SUBJECTS/Chemistry.html', {'ChemistryPapers': ChemistryPapers})

def ED(request):
    EDPapers = EDQ1.objects.all()
    return render(request,'CSE-SEM1-SUBJECTS/Engineering-Drawing.html',{'EDPapers': EDPapers})


def CSE2(request):
    return render(request,'CSE-SEM2-SUBJECTS/CSE-SEMESTERS2-S.html')

def BE(request):
    BEPapers = BEQ1.objects.all()
    return render(request,'CSE-SEM2-SUBJECTS/BE.html', {'BEPapers': BEPapers})

def Maths2(request):
    Maths2Papers = Maths2Q1.objects.all()
    return render(request,'CSE-SEM2-SUBJECTS/Maths-2.html', {'Maths2Papers': Maths2Papers})

def EVS(request):
    EVSPapers = EVSQ1.objects.all()
    return render(request,'CSE-SEM2-SUBJECTS/EVS.html', {'EVSPapers': EVSPapers})

def Phyics2(request):
    AP2Papers = AP2Q1.objects.all()
    return render(request,'CSE-SEM2-SUBJECTS/BE.html', {'AP2Papers': AP2Papers})

def DTP(request):
    DTPPapers = DTPQ1.objects.all()
    return render(request,'CSE-SEM2-SUBJECTS/DTP.html', {'DTPPapers': DTPPapers})

def ECS2(request):
    ECS2Papers = ECS2Q1.objects.all()
    return render(request,'CSE-SEM2-SUBJECTS/ECS-2.html', {'ECS2Papers': ECS2Papers})

def CSE3(request):
    return render(request,'CSE-SEM3-SUBJECTS/CSE-SEMESTERS3-S.html')
    
def CPC(request):
    CPCPapers = CPCQ1.objects.all()
    return render(request,'CSE-SEM3-SUBJECTS/CPC.html', {'CPCPapers': CPCPapers})

def DE(request):
    DEPapers = DEQ1.objects.all()
    return render(request,'CSE-SEM3-SUBJECTS/DE.html', {'DEPapers': DEPapers})

def SE(request):
    SEPapers = SEQ1.objects.all()
    return render(request,'CSE-SEM3-SUBJECTS/IWT.html', {'SEPapers': SEPapers})

def OS(request):
    OSPapers = OSQ1.objects.all()
    return render(request,'CSE-SEM3-SUBJECTS/MMA.html', {'OSPapers': OSPapers})

def MMA(request):
    MMAPapers = MMAQ1.objects.all()
    return render(request,'CSE-SEM3-SUBJECTS/OS.html', {'MMAPapers': MMAPapers})

def IWT(request):
    IWTPapers = IWTQ1.objects.all()
    return render(request,'CSE-SEM3-SUBJECTS/SE.html', {'IWTPapers': IWTPapers})

def CSE4(request):
    return render(request,'CSE-SEM4-SUBJECTS/CSE-SEMESTERS4-S.html')

def CA(request):
    CAPapers = CAQ1.objects.all()
    return render(request, 'CSE-SEM4-SUBJECTS/CA.html', {'CAPapers': CAPapers})

def CNS(request):
    CNSPapers = CNSQ1.objects.all()
    return render(request, 'CSE-SEM4-SUBJECTS/CNS.html', {'CNSPapers': CNSPapers})

def DBMS(request):
    DBMSPapers = DBMSQ1.objects.all()
    return render(request, 'CSE-SEM4-SUBJECTS/DBMS.html', {'DBMSPapers': DBMSPapers})

def DS(request):
    DSPapers = DSQ1.objects.all()
    return render(request, 'CSE-SEM4-SUBJECTS/DS.html', {'DSPapers': DSPapers})

def GSED(request):
    GSEDPapers = GSEDQ1.objects.all()
    return render(request, 'CSE-SEM4-SUBJECTS/GSED.html', {'GSEDPapers': GSEDPapers})

def OOPS(request):
    OOPSPapers = OOPSQ1.objects.all()
    return render(request, 'CSE-SEM4-SUBJECTS/OOPS.html', {'OOPSPapers': OOPSPapers})



def CSE5(request):
    return render(request,'CSE-SEM5-SUBJECTS/CSE-SEMESTERS5-S.html')

def BOM(request):
    BOMPapers = BOMQ1.objects.all()
    return render(request, 'CSE-SEM5-SUBJECTS/BOM.html', {'BOMPapers': BOMPapers})

def CPI(request):
    CPIPapers = CPIQ1.objects.all()
    return render(request, 'CSE-SEM5-SUBJECTS/CPI.html', {'CPIPapers': CPIPapers})

def IOT(request):
    IOTPapers = IOTQ1.objects.all()
    return render(request, 'CSE-SEM5-SUBJECTS/IOT.html', {'IOTPapers': IOTPapers})

def MicroProcessor(request):
    MicroProcessorPapers = MicroProcessorQ1.objects.all()
    return render(request, 'CSE-SEM5-SUBJECTS/MicroProcessor.html', {'MicroProcessorPapers': MicroProcessorPapers})

def MT(request):
    MTPapers = MTQ1.objects.all()
    return render(request, 'CSE-SEM5-SUBJECTS/MT.html', {'MTPapers': MTPapers})

def PHP(request):
    PHPPapers = PHPQ1.objects.all()
    return render(request, 'CSE-SEM5-SUBJECTS/PHP.html', {'PHPPapers': PHPPapers})


def CSE6(request):
    return render(request,'CSE-SEM6-SUBJECTS/CSE-SEMESTERS6-S.html')

def ADL(request):
    ADLPapers = ADLQ1.objects.all()
    return render(request, 'CSE-SEM6-SUBJECTS/ADL.html', {'ADLPapers': ADLPapers})

def ADWF(request):
    ADWFPapers = ADWFQ1.objects.all()
    return render(request, 'CSE-SEM6-SUBJECTS/ADWF.html', {'ADWFPapers': ADWFPapers})

def CC(request):
    CCPapers = CCQ1.objects.all()
    return render(request, 'CSE-SEM6-SUBJECTS/CC.html', {'CCPapers': CCPapers})

def CPP(request):
    CPPPapers = CPPQ1.objects.all()
    return render(request, 'CSE-SEM6-SUBJECTS/CPP.html', {'CPPPapers': CPPPapers})

def DAA(request):
    DAAPapers = DAAQ1.objects.all()
    return render(request, 'CSE-SEM6-SUBJECTS/DAA.html', {'DAAPapers': DAAPapers})

def PHP2(request):
    PHP2Papers = PHPQ2.objects.all()
    return render(request, 'CSE-SEM6-SUBJECTS/PHP2.html', {'PHP2Papers': PHP2Papers})



def CIVIL(request):
    return render(request,'CIVIL-SEMESTERS-W.html')

def ARC(request):
    return render(request,'ARC-SEMESTERS-W.html')

def ELECTRICAL(request):
    return render(request,'ELECTRICAL-SEMESTERS-W.html')

def MECHANICAL(request):
    return render(request,'MECHANICAL-SEMESTERS-W.html')