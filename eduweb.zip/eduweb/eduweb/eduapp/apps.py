from django.apps import AppConfig


class EduappConfig(AppConfig):
    name = 'eduapp'
