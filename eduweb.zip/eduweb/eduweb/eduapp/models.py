from django.db import models

class Message(models.Model):
    """
    Message model for contact us form.
    """
    email = models.EmailField()
    name = models.CharField(max_length=100)
    message = models.TextField()
    date = models.DateTimeField()
    def __str__(self):
        return self.name
    
class PhysicsQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='Physic1Papers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.title
    
class MathsQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='Maths1Papers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.title
    
class ChemistryQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='ChemistryPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.title

class CFITQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='CFITPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.title
    
class ECSQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='ECSPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.title
    
class EDQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='EDPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.title
    
class BEQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='BEPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.title
    
class Maths2Q1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='EDPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.title

class EVSQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='EVSPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.title
    
class AP2Q1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='AP2Papers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.title

class DTPQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='DTPPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.title

class ECS2Q1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='ECS2Papers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.title

class CPCQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='CPCPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.title
    
class DEQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='DEPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.title
    
class SEQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='SEPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.title
class OSQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='OSPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.title
class MMAQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='MMAPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.title
class IWTQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='IWTPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.title
    
class CAQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='CAPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.title

class CNSQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='CNSPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.title

class DBMSQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='DBMSPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.title

class DSQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='DSPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.title

class GSEDQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='GSEDPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.title

class OOPSQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='OOPSPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.title


class BOMQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='BOMPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class CPIQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='CPIPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class IOTQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='IOTPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class MicroProcessorQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='MicroProcessorPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class MTQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='MTPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class PHPQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='PHPPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class ADLQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='ADLPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class ADWFQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='ADWFPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class CCQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='CCPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class CPPQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='CPPPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class DAAQ1(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='DAAPapers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class PHPQ2(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='PHP2Papers/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title
